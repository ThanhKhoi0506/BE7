using System.ComponentModel.DataAnnotations;

namespace ThanhKhoi_25DH230053.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        [Required, StringLength(50)]
        public string Username { get; set; }
        [Required, StringLength(120)]
        public string FullName { get; set; }
        [StringLength(20)]
        public string Phone { get; set; }
        [EmailAddress, StringLength(120)]
        public string Email { get; set; }
        [StringLength(300)]
        public string Address { get; set; }
    }
}

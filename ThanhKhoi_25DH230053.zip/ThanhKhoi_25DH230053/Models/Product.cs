using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThanhKhoi_25DH230053.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        [Required, StringLength(160)]
        [Display(Name = "Tên sản phẩm")]
        public string ProductName { get; set; }
        [StringLength(1000)]
        [Display(Name = "Mô tả")]
        public string Description { get; set; }
        [Range(0, 100000000)]
        [Column(TypeName = "money")]
        [Display(Name = "Đơn giá")]
        public decimal Price { get; set; }
        [StringLength(500)]
        [Display(Name = "Đường dẫn ảnh")]
        public string ImageUrl { get; set; }
        public int CategoryId { get; set; }
        public int SoldCount { get; set; }
        public virtual Category Category { get; set; }
    }
}

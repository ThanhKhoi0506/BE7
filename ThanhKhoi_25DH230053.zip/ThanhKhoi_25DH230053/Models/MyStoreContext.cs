using System.Data.Entity;
using System.Linq;

namespace ThanhKhoi_25DH230053.Models
{
    public class MyStoreContext : DbContext
    {
        public MyStoreContext() : base("MyStoreConnection") { }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
    }

    public class MyStoreInitializer : CreateDatabaseIfNotExists<MyStoreContext>
    {
        protected override void Seed(MyStoreContext db)
        {
            var coffee = new Category { CategoryName = "Cà phê" };
            var tea = new Category { CategoryName = "Trà" };
            var equipment = new Category { CategoryName = "Dụng cụ" };
            db.Categories.Add(coffee); db.Categories.Add(tea); db.Categories.Add(equipment);
            db.SaveChanges();
            db.Products.Add(new Product { ProductName="Cà phê sữa đá", Description="Cà phê đậm vị cùng sữa đặc.", Price=35000, ImageUrl="https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600", CategoryId=coffee.CategoryId, SoldCount=120 });
            db.Products.Add(new Product { ProductName="Latte", Description="Espresso và sữa tươi mịn.", Price=55000, ImageUrl="https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600", CategoryId=coffee.CategoryId, SoldCount=95 });
            db.Products.Add(new Product { ProductName="Trà đào", Description="Trà trái cây thanh mát.", Price=45000, ImageUrl="https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600", CategoryId=tea.CategoryId, SoldCount=80 });
            db.Products.Add(new Product { ProductName="Trà xanh", Description="Hương trà xanh nhẹ nhàng.", Price=40000, ImageUrl="https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600", CategoryId=tea.CategoryId, SoldCount=65 });
            db.Products.Add(new Product { ProductName="Ly giữ nhiệt", Description="Ly dùng nhiều lần.", Price=120000, ImageUrl="https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=600", CategoryId=equipment.CategoryId, SoldCount=20 });
            db.SaveChanges();
            base.Seed(db);
        }
    }
}

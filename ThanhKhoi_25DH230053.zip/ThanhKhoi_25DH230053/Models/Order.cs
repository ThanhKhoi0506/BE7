using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ThanhKhoi_25DH230053.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        [Required, StringLength(50)]
        public string Username { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
        [StringLength(40)]
        public string DeliveryMethod { get; set; }
        [StringLength(40)]
        public string PaymentMethod { get; set; }
        [StringLength(300)]
        public string ShippingAddress { get; set; }
        [StringLength(40)]
        public string Status { get; set; }
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
        public Order() { OrderDetails = new HashSet<OrderDetail>(); }
    }
    public class OrderDetail
    {
        public int OrderDetailId { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get { return Quantity * UnitPrice; } }
        public virtual Order Order { get; set; }
    }
}

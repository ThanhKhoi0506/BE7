using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ThanhKhoi_25DH230053.Models
{
    public class RegisterVM
    {
        [Required, StringLength(50), Display(Name="Tên đăng nhập")]
        public string Username { get; set; }
        [Required, StringLength(100, MinimumLength=6), DataType(DataType.Password), Display(Name="Mật khẩu")]
        public string Password { get; set; }
        [Required, Compare("Password"), DataType(DataType.Password), Display(Name="Nhập lại mật khẩu")]
        public string ConfirmPassword { get; set; }
        [Required, Display(Name="Họ tên")]
        public string FullName { get; set; }
        [EmailAddress, Display(Name="Email")]
        public string Email { get; set; }
        [Display(Name="Số điện thoại")]
        public string Phone { get; set; }
        [Display(Name="Địa chỉ")]
        public string Address { get; set; }
    }
    public class LoginVM
    {
        [Required, Display(Name="Tên đăng nhập")]
        public string Username { get; set; }
        [Required, DataType(DataType.Password), Display(Name="Mật khẩu")]
        public string Password { get; set; }
        [Display(Name="Ghi nhớ đăng nhập")]
        public bool RememberMe { get; set; }
    }
    public class CheckoutVM
    {
        [Required, Display(Name="Địa chỉ giao hàng")]
        public string ShippingAddress { get; set; }
        [Required, Display(Name="Hình thức giao hàng")]
        public string DeliveryMethod { get; set; }
        [Required, Display(Name="Hình thức thanh toán")]
        public string PaymentMethod { get; set; }
    }
    public class HomeProductVM
    {
        public List<Product> FeaturedProducts { get; set; }
        public List<Product> NewProducts { get; set; }
        public string SearchTerm { get; set; }
    }
    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ImageUrl { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get { return UnitPrice * Quantity; } }
    }
}

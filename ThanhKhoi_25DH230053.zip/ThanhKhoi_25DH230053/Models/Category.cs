using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ThanhKhoi_25DH230053.Models
{
    public class Category
    {
        public int CategoryId { get; set; }

        [Required, StringLength(100)]
        [Display(Name = "Tên danh mục")]
        public string CategoryName { get; set; }

        public virtual ICollection<Product> Products { get; set; }
        public Category() { Products = new HashSet<Product>(); }
    }
}

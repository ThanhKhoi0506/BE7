BAI WEB BACK-END DEVELOPMENT - CUSTOMER SITE
Ten bai: ThanhKhoi_25DH230053
Cong nghe: ASP.NET MVC 5, Entity Framework 6, C#, SQL Server LocalDB

LUU Y:
- Day la bo ma nguon MVC5 de mo/chuyen vao Visual Studio 2022, khong phai file .exe.
- May can cai Visual Studio 2022 workload "ASP.NET and web development" va .NET Framework 4.8 Developer Pack.
- Tao project ASP.NET Web Application (.NET Framework) > MVC trong Visual Studio 2022, sau do chep cac thu muc/file trong goi nay vao project MVC moi.
- Cai NuGet: EntityFramework (6.4.4). Neu dung PagedList.Mvc thi cai them PagedList.Mvc; bo ma nay khong bat buoc PagedList.
- Chinh chuoi ket noi MyStoreConnection trong Web.config neu SQL Server may ban khac LocalDB.
- Lan dau chay, EF se tao database MyStore trong LocalDB va nap du lieu mau.
- Du lieu tai khoan demo: username demo, password Demo123!
- Day la ban nen tang de hoc va phat trien theo slide; cac tinh nang thanh toan PayPal that, phan trang nang cao va quan tri Admin chua duoc tich hop day du.
- Neu chua cai Visual Studio, ban van co the tai file nay va gui cho may co Visual Studio de mo; ban than file ZIP khong tu chay duoc.

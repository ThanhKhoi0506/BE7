using System;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ThanhKhoi_25DH230053.Models;

namespace ThanhKhoi_25DH230053.Controllers
{
    public class OrderController : Controller
    {
        private MyStoreContext db = new MyStoreContext();
        [Authorize] public ActionResult Checkout()
        {
            var cart=Session["Cart"] as System.Collections.Generic.List<CartItem>;
            if(cart==null || !cart.Any()) return RedirectToAction("Index","Cart");
            var c=db.Customers.FirstOrDefault(x=>x.Username==User.Identity.Name);
            return View(new CheckoutVM { ShippingAddress=c==null?"":c.Address, DeliveryMethod="Giao hàng tiêu chuẩn", PaymentMethod="COD" });
        }
        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult Checkout(CheckoutVM vm)
        {
            var cart=Session["Cart"] as System.Collections.Generic.List<CartItem>;
            if(cart==null || !cart.Any()) return RedirectToAction("Index","Cart");
            if(!ModelState.IsValid) return View(vm);
            var order=new Order { Username=User.Identity.Name, OrderDate=DateTime.Now, DeliveryMethod=vm.DeliveryMethod, PaymentMethod=vm.PaymentMethod, ShippingAddress=vm.ShippingAddress, Status="Đang xử lý", TotalAmount=cart.Sum(x=>x.TotalPrice) };
            foreach(var item in cart) order.OrderDetails.Add(new OrderDetail { ProductId=item.ProductId, ProductName=item.ProductName, Quantity=item.Quantity, UnitPrice=item.UnitPrice });
            db.Orders.Add(order); db.SaveChanges(); Session["Cart"]=null;
            return RedirectToAction("OrderSuccess", new { id=order.OrderId });
        }
        [Authorize] public ActionResult OrderSuccess(int id)
        {
            var order=db.Orders.Include("OrderDetails").FirstOrDefault(o=>o.OrderId==id && o.Username==User.Identity.Name);
            if(order==null) return HttpNotFound();
            return View(order);
        }
        [Authorize] public ActionResult OrderHistory()
        {
            return View(db.Orders.Include("OrderDetails").Where(o=>o.Username==User.Identity.Name).OrderByDescending(o=>o.OrderDate).ToList());
        }
    }
}

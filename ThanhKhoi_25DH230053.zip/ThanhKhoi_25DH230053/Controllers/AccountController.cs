using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using ThanhKhoi_25DH230053.Models;

namespace ThanhKhoi_25DH230053.Controllers
{
    public class AccountController : Controller
    {
        private MyStoreContext db = new MyStoreContext();
        [HttpGet] public ActionResult Register() { return View(); }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Register(RegisterVM vm)
        {
            if (!ModelState.IsValid) return View(vm);
            if (db.Customers.Any(c => c.Username == vm.Username)) { ModelState.AddModelError("Username", "Tên đăng nhập đã tồn tại."); return View(vm); }
            // Demo coursework only: replace with a proper password hasher for production.
            Session["Password_" + vm.Username] = vm.Password;
            db.Customers.Add(new Customer { Username=vm.Username, FullName=vm.FullName, Email=vm.Email, Phone=vm.Phone, Address=vm.Address });
            db.SaveChanges();
            FormsAuthentication.SetAuthCookie(vm.Username, false);
            return RedirectToAction("Index", "Home");
        }
        [HttpGet] public ActionResult Login() { return View(); }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(LoginVM vm)
        {
            if (!ModelState.IsValid) return View(vm);
            var customer = db.Customers.FirstOrDefault(c => c.Username == vm.Username);
            if (customer != null && (string.Equals(Session["Password_" + vm.Username] as string, vm.Password) || (vm.Username == "demo" && vm.Password == "Demo123!")))
            {
                FormsAuthentication.SetAuthCookie(vm.Username, vm.RememberMe);
                Session["Username"] = vm.Username;
                return RedirectToAction("Index", "Home");
            }
            ModelState.AddModelError("", "Tên đăng nhập hoặc mật khẩu không đúng. Tài khoản demo chỉ dùng sau khi được tạo.");
            return View(vm);
        }
        public ActionResult Logout() { FormsAuthentication.SignOut(); Session.Clear(); return RedirectToAction("Index", "Home"); }
        [Authorize] public ActionResult ProfileInfo()
        {
            var c = db.Customers.FirstOrDefault(x => x.Username == User.Identity.Name);
            if (c == null) return RedirectToAction("Login");
            return View(c);
        }
        [HttpPost, Authorize, ValidateAntiForgeryToken]
        public ActionResult ProfileInfo(Customer model)
        {
            var c = db.Customers.FirstOrDefault(x => x.Username == User.Identity.Name);
            if (c == null) return RedirectToAction("Login");
            if (ModelState.IsValid) { c.FullName=model.FullName; c.Phone=model.Phone; c.Email=model.Email; c.Address=model.Address; db.SaveChanges(); ViewBag.Message="Đã cập nhật thông tin."; }
            return View(c);
        }
    }
}

using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using ThanhKhoi_25DH230053.Models;

namespace ThanhKhoi_25DH230053.Controllers
{
    public class HomeController : Controller
    {
        private MyStoreContext db = new MyStoreContext();
        public ActionResult Index(string searchTerm)
        {
            var products = db.Products.Include(p => p.Category).AsQueryable();
            if (!string.IsNullOrWhiteSpace(searchTerm))
                products = products.Where(p => p.ProductName.Contains(searchTerm) || p.Description.Contains(searchTerm) || p.Category.CategoryName.Contains(searchTerm));
            var list = products.ToList();
            var vm = new HomeProductVM { SearchTerm = searchTerm, FeaturedProducts = list.OrderByDescending(p => p.SoldCount).Take(10).ToList(), NewProducts = list.OrderByDescending(p => p.ProductId).Take(20).ToList() };
            return View(vm);
        }
        public ActionResult ProductList(int? categoryId, string searchTerm)
        {
            var products = db.Products.Include(p => p.Category).AsQueryable();
            if (categoryId.HasValue) products = products.Where(p => p.CategoryId == categoryId.Value);
            if (!string.IsNullOrWhiteSpace(searchTerm)) products = products.Where(p => p.ProductName.Contains(searchTerm));
            ViewBag.Categories = new SelectList(db.Categories.ToList(), "CategoryId", "CategoryName", categoryId);
            ViewBag.CategoryId = categoryId;
            return View(products.OrderBy(p => p.ProductName).ToList());
        }
        public ActionResult ProductDetail(int id)
        {
            var product = db.Products.Include(p => p.Category).FirstOrDefault(p => p.ProductId == id);
            if (product == null) return HttpNotFound();
            ViewBag.RelatedProducts = db.Products.Where(p => p.CategoryId == product.CategoryId && p.ProductId != id).Take(8).ToList();
            return View(product);
        }
    }
}

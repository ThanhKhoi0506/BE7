using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using ThanhKhoi_25DH230053.Models;

namespace ThanhKhoi_25DH230053.Controllers
{
    public class CartController : Controller
    {
        private MyStoreContext db = new MyStoreContext();
        private List<CartItem> Items { get { if (Session["Cart"] == null) Session["Cart"] = new List<CartItem>(); return (List<CartItem>)Session["Cart"]; } }
        public ActionResult Index() { return View(Items); }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult AddItem(int productId, int quantity = 1)
        {
            var p = db.Products.Find(productId); if (p == null) return HttpNotFound();
            var item = Items.FirstOrDefault(x => x.ProductId == productId);
            if (item == null) Items.Add(new CartItem { ProductId=p.ProductId, ProductName=p.ProductName, ImageUrl=p.ImageUrl, UnitPrice=p.Price, Quantity=System.Math.Max(1, quantity) });
            else item.Quantity += System.Math.Max(1, quantity);
            return RedirectToAction("Index");
        }
        [HttpPost, ValidateAntiForgeryToken] public ActionResult UpdateQuantity(int productId, int quantity)
        {
            var item=Items.FirstOrDefault(x=>x.ProductId==productId);
            if(item!=null) { if(quantity<=0) Items.Remove(item); else item.Quantity=quantity; }
            return RedirectToAction("Index");
        }
        [HttpPost, ValidateAntiForgeryToken] public ActionResult RemoveItem(int productId) { var i=Items.FirstOrDefault(x=>x.ProductId==productId); if(i!=null) Items.Remove(i); return RedirectToAction("Index"); }
        [HttpPost, ValidateAntiForgeryToken] public ActionResult ClearCart() { Items.Clear(); return RedirectToAction("Index"); }
    }
}

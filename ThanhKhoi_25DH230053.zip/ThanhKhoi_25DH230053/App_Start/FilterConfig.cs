using System.Web.Mvc;
namespace ThanhKhoi_25DH230053
{
    public class FilterConfig { public static void RegisterGlobalFilters(GlobalFilterCollection filters) { filters.Add(new HandleErrorAttribute()); } }
}
